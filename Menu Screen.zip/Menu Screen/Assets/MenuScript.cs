using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuScript : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision) //collides with the player
    {
        SceneManager.LoadScene(2); //loads the level
    }

    public void Quit() //a private void for the quiting the game
    {
        Application.Quit(); //makes the whole application quit when selected
    }
    public void LoadLevel(int level) //making the level loaded by the integer
    {
        SceneManager.LoadScene(level); //allowing to move levels
    }

    public void Setup() //creates a setup
    {
        gameObject.SetActive(true); //this makes the sprite render set active
    }
}
